const dotenv = require('dotenv').config({
    path: './.env'
}, {
    encoding: 'utf-8'
});
const Translate = require('@google-cloud/translate');
const projectId = process.env.GOOGLE_PROJECT_ID;
const translator = new Translate({
    projectId: projectId,
});

const
    translateText = (text, target, options, callback) => {
        translator
            .translate(text, {
                to: target,
                from: options.source,
                model: options.model
            })
            .then(results => {
                const translation = results[0];
                callback(translation);
            })
            .catch(err => {
                console.error('ERROR: ', err);
            });
    };

const
    promiseTranslate = (text, source, target) => {
        return translator
            .translate(text, {
                from: source,
                to: target
            })
    };

const
    detectLanguage = (text, callback) => {
        translator
            .detect(text)
            .then(results => {
                const detections = results[0];
                detections = Array.isArray(detections) ? detections : [detections];
                console.log('Detections:');
                detections.forEach(detection => {
                    console.log(`${detection.input} => ${detection.language}`);
                });
            })
            .catch(err => {
                console.error('ERROR:', err);
            });
    }

const
    listLanguages = (text, options, callback) => {
        translator
            .getLanguages(options.target)
            .then(results => {
                const languages = results[0];
                console.log('Languages:');
                languages.forEach(language => console.log(language));
            })
            .catch(err => {
                console.error('ERROR:', err);
            });
    }

module.exports = {
    promiseTranslate,
    translateText,
    detectLanguage,
    listLanguages
};