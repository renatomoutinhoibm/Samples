const request = require('request');

const
    getBacenMonth = (indice, start_date, end_date) => {
        return new Promise((resolve, reject) => {
            let options = {
                url: `https://www.quandl.com/api/v3/datasets/BCB/${indice}.json?start_date=${start_date}&end_date=${end_date}&api_key=XfwGVKy8vx_2B9ZftL7e`
            }
            request.get(options, (err, res, body) => {
                resolve(body);
            });
        });
    };

const
    getBacenDay = (indice, start_date, end_date) => {
        return new Promise((resolve, reject) => {
            let options = {
                url: `https://www.quandl.com/api/v3/datasets/BCB/${indice}.json?start_date=${start_date}&end_date=${end_date}&api_key=XfwGVKy8vx_2B9ZftL7e`
            }
            request.get(options, (err, res, body) => {
                if (err) reject(err);
                console.log(body);
                resolve(body);
            });
        });
    }

module.exports = {
    getBacenDay,
    getBacenMonth
}