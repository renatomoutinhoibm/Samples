const requestPromise = require('request-promise-native');
//const api = "http://localhost:6013";
const api = "https://inoabra-predictive-market.mybluemix.net"


const naturalLanguageGeneration = (risk, shock) => {
    return new Promise((resolve, reject) => {
        let factor;
        let holdings;
        let model;
        for (let i = 0; i < riskList.length; i++) {
            if (riskList[i][1] === risk) {
                factor = riskList[i][0];
                break;
            }
        }

        let options = {
            method: 'POST',
            uri: api + '/api/predict',
            body: {
                risk: factor,
                shock: shock
            },
            json: true
        };
        console.log("parte 1 da demo");
        requestPromise(options)
            .then(function (parsedBody) {
                let options = {
                    method: 'GET',
                    uri: api + '/api/holdings?portfolio=InovaBraIncomePortifolio',
                    json: true
                };
                model = parsedBody.model;
                console.log("parte 2 da demo");
                return requestPromise(options);
            })
            .then((parsedBody) => {
                options.uri = api + '/api/instrument';
                options.method = 'POST';
                options.body = {
                    holdings: parsedBody.holdings[0].holdings,
                    model: model
                };
                holdings = parsedBody.holdings;
                console.log("parte 3 da demo");
                //console.log(options);
                return requestPromise(options);
            })
            .then((parsedBody) => {
                let options = {
                    uri: api + '/api/arria',
                    method: 'POST',
                    body: parsedBody,
                    json: true
                }
                options.body.factor = factor;
                options.body.shock = shock
                options.body.risk = risk;
                console.log("parte 4 da demo");
                //console.log(JSON.stringify(options));
                return requestPromise(options);
            })
            .then((parsedBody) => {
                resolve(parsedBody)

            })
            .catch(function (err) {
                reject(err);

            });
    });
}

const riskList = [
    ['CX_EQI_SPDJ_USA500_BMK_USD_LargeCap_Price', 'S&P 500 Index'],
    ['CX_EQI_NYSE_USA_BMK_USD_LargeCap_Price', 'NYSE MKT Composite Index'],
    ['CX_EQI_NASD_USAComposite_BMK_USD_LargeCap_Price', 'NASDAQ Composite Index'],
    ['CX_EQI_NYSE_CAC40_BMK_EUR_LargeCap_Price', 'CAC 40 Index'],
    ['CX_EQI_NIKK_Asia_BMK_JPY_LargeCap_Price', 'Nikkei 225 Index'],
    ['CX_EQI_HSNG_Asia_BMK_HKD_LargeCap_Price', 'Hang Seng Index'],
    ['CX_EQI_FTSE_UK_BMK_GBP_LargeCap_Price', 'FTSE 100 Index'],
    ['CX_FXC_EUR_USD_Spot', 'EUR/USD FX rate'],
    ['CX_FXC_JPY_USD_Spot', 'JPY/USD FX rate'],
    ['CX_FXC_CAD_USD_Spot', 'CAD/USD FX rate'],
    ['CX_FXC_GBP_USD_Spot', 'GBP/USD  FX rate'],
    ['CX_COS_EN_BrentCrude_IFEU', 'Spot Price of Brent Crude Oil'],
    ['CX_COS_EN_WTICrude_IFEU', 'Spot Price of WTI Crude Oil'],
    ['CX_COS_ME_Gold_XCEC', 'Spot Price of Gold']
];

module.exports = {
    naturalLanguageGeneration
}