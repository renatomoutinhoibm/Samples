let request = require('request');
let cheerio = require('cheerio');

// let stock = `bbdc4`;

const getQuotation = (paper) => {
    return new Promise((resolve, reject) => {
        let url = `https://www.google.com/search?q=cotação++ ${paper}`;
        request(url, function (error, response, body) {
            if (!error) {
                const $ = cheerio.load(body)
    
                let title = $('title').text();
                let content = $('body').text();
                let signalPos = 0;
    
                let result = $('span.f').parent().children('span').first().text();
                if (paper === 'BBD') signalPos = 5;
                else signalPos = 6;
    
                let conv = result.replace(" ", "#");
                conv = conv.replace(" ", "#");
                let result2 = conv.split("#");
                // let signal = result2[0].charAt(6);
                let signal = result2[0].charAt(signalPos);
                let stock = result2[0].split(signal);
                let variation = result2[1].replace('(', '').replace(')', '').replace('%', '');
                let x = result2[0].split(signal);
    
    
    
                // console.log("URL: " + url);
                // console.log("Title: " + title);
                // console.log("Stock Price: " + result2[0]);
                // console.log("Variation(R$): " + result2[1]);
                // console.log("Variation: " + signal + result2[2]);
                console.log(result)
    
                resolve([stock[0], signal + variation, signal +stock[1]])
    
            }
            else {
                reject(err);
                console.log("We've encountered an error: " + error);
            }
        });
    });
}

const getMoney = (money) =>{
    return new Promise((resolve, reject) => {
        let url = 'https://www.dolarhoje.net.br';
        
            
            request(url, function (error, response, body) {
                if (!error) {
                    const $ = cheerio.load(body)
        
                    let title = $('title').text();
                    let content = $('body').text();
        
                    let result = $('tbody').text().split("\n");
                    let comercial = result[2].replace(/^\s+/g, '') + ': ' + result[3].replace(/\s/g, '');
                    let tur = result[6].replace(/^\s+/g, '') + ': ' + result[7].replace(/\s/g, '');
                    let ptax = result[10].replace(/^\s+/g, '') + ': ' + result[11].replace(/\s/g, '');
        
        
                    // console.log('URL: ' + url);
                    // console.log('Title: ' + title);
                    if (money == 'dólar comercial') resolve(comercial.split(':'));
                    else if (money == 'dólar turismo') resolve(tur.split(':'));
                    else resolve(ptax.split(':'));
        
        
                }
                else {
                    console.log("We've encountered an error: " + error);
                    reject(err);
                }
            });
    });
}


module.exports = {getQuotation, getMoney};