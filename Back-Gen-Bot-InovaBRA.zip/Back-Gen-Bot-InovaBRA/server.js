const // NPM
    dotenv = require('dotenv').config({
        path: './.env'
    }, {
        encoding: 'utf-8'
    }),
    bodyParser = require('body-parser'),
    express = require('express'),
    cors = require('cors'),
    server = express();
const // DB
    db2 = require('./watson_cloud/db2');
// cloudant = require('./watson_cloud/cloudant');
const // Watson
    nlu = require('./watson_cloud/nlu'),
    assistant = require('./watson_cloud/assistant'),
    translator = require('./watson_cloud/translator'),
    discovery = require('./watson_cloud/discovery'),
    tone_analyzer = require('./watson_cloud/tone_analyzer');
const // Services
    bacen = require('./services/bacen'),
    arria = require('./services/arria'),
    translator2 = require('./google/translator');
const //Actions
    demo = require('./actions/demo'),
    indice = require('./actions/indice');
feed = require('./actions/feed');

server.set('port', process.env.PORT || 3000);
server.engine('html', require('ejs').renderFile);
server.set('view engine', 'ejs');
server.use(express.static('public'));
server.get('/', (req, res) => {
    res.render('index.html');
});
server.use(bodyParser.json());
server.use(bodyParser.urlencoded({
    extended: true
}));
server.use(cors());

server.get('/api/translator', (req, res) => {
    let text = req.query.text;
    let source = req.query.source;
    let target = req.query.target;
    translator2.promiseTranslate(text, source, target)
        .then(response => res.json({
            translated: response[0]
        }))
        .catch(e => res.send(e));
});

server.get('/api/tone', (req, res) => {
    let text = req.query.text;
    translator2.promiseTranslate(text, 'pt', 'en')
        .then(response => {
            nlu.analyze(response[0], 'text', 'en').then(result => {
                    let emotion = result.sentiment.document.label;
                    let score = result.sentiment.document.score;
                    if (emotion === 'neutral') emotion = 'positive';
                    res.json({
                        emotion,
                        score
                    });
                })
                .catch(e => res.send(e));
        })
        .catch(e => res.send(e));
});

server.get('/api/feed', (req, res) => {
    let query = req.query.q;
    feed.getFeed(query).then((feed) => {
        res.json(feed);
    }).catch((err) => {
        res.json(err);
    })
});

server.post('/api/conversation', (req, res) => {
    if (req.body) {
        let payload = req.body;
        if (payload.input.text) {
            verifyEmotion(payload.input.text)
                .then(emotion => {
                    payload.context.emotion = emotion;
                    Interaction(payload, res);
                })
                .catch(e => {
                    payload.context.emotion = {
                        emotion: 'positive',
                        score: 0
                    };
                    Interaction(payload, res)});
        } else {
            payload.context.emotion = {
                emotion: 'positive',
                score: 0
            };
            Interaction(payload, res);
        }
    };
});

server.listen(server.get('port'), '0.0.0.0', () => {
    console.log(`Server is listening on port: ${server.get('port')}`);
});

function Interaction(payload, res) {
    let flagPeriodo = 0;
    let start_month = 0;
    let end_month = 0;
    assistant.message(payload, (conv_response) => {
        if (conv_response.output.action === 'indice') {
            indice.execute(conv_response).then((new_conv_response) => {
                return res.json(new_conv_response);
            });
        } else if (conv_response.output.action === "demo") {
            demo.execute(conv_response).then((new_conv_response) => {
                return res.json(new_conv_response);
            });
        } else if (conv_response.output.action === 'feed') {
            if (conv_response.context.indice) {
                feed.getEarliestNews(conv_response.context.indice).then((summary) => {
                    if (summary) {
                        conv_response.output.text.push("<p>" + summary.title + "</p><p>" + summary.content + "</p><a href='" + summary.url + "' target='_blank'>Veja aqui a notícia completa</a><p>" + summary.date + "</p>")
                        conv_response.context.discovery = true;
                    } else {
                        conv_response.context.discovery = false;
                        if (conv_response.output.alternate) {
                            conv_response.output.text[0] = conv_response.output.alternate;
                        }
                    }
                    res.json(conv_response);
                });
            } else {
                res.status(404).json({
                    error: "No index found"
                });
            }
        } else if (conv_response.output.action === "discovery") {
            discovery.WDSquery(conv_response.context.indice, 'query').then(documents => {
                if (documents.matching_results <= 0) {
                    conv_response.context.discovery = false;
                    if (conv_response.output.alternate) {
                        conv_response.output.text[0] = conv_response.output.alternate;
                    }
                } else {
                    conv_response.output.text.push(documents.results[0].summary
                        .replace(/<img[^>]*>/g, '')); // Regex para retirar imagens
                    if (conv_response.output.alternate && conv_response.output.no_arria) {
                        conv_response.output.text.push(conv_response.output.alternate);
                    }
                }
                res.json(conv_response);
            }).catch((err) => {
                console.log(err)
            });
        } else if (conv_response.output.action == undefined) return res.json(conv_response);
    });
}

function verifyEmotion(text) {
    return new Promise((resolve, reject) => {
        translator2.promiseTranslate(text, 'pt', 'en')
            .then(response => {
                nlu.analyze(response[0], 'text', 'en').then(result => {
                        let emotion = result.sentiment.document.label;
                        let score = result.sentiment.document.score;
                        if (emotion === 'neutral') emotion = 'positive';
                        resolve({
                            emotion,
                            score
                        });
                    })
                    .catch(e => reject(e));;
            })
            .catch(e => reject(e));
    });
}