const dotenv = require('dotenv').config({
    path: './.env'
}, {
    encoding: 'utf-8'
});
const LanguageTranslatorV2 = require('watson-developer-cloud/language-translator/v2');
const languageTranslator = new LanguageTranslatorV2({
    username: process.env.TRANSLATOR_USERNAME,
    password: process.env.TRANSLATOR_PASSWORD
});

const
    translateText = (text, target, options, callback) => {
        const parameters = {
            text: text,
            target: target,
            source: options.source,
            model_id: options.model,
        };
        languageTranslator.translate(parameters, (error, response) => {
            if (error) console.log(error)
            else {
                const translation = response.translations[0].translation;
                callback(translation);
            }
        });
    }

const
    detectLanguage = (text, callback) => {
        const parameters = {
            text: text
        };
        languageTranslator.identify(parameters, (error, response) => {
            if (error) console.log(error)
            else console.log(JSON.stringify(response, null, 2));
        });
    }

const
    listLanguages = (callback) => {
        languageTranslator.getIdentifiableLanguages({}, (err, response) => {
            if (err) console.log(err)
            else console.log(JSON.stringify(response, null, 2));
        });
    }

const
    promiseTranslate = (text, source, target) => {
        return new Promise((resolve, reject) => {
            const parameters = {
                text: text,
                model_id: `${source}-${target}`,
                // source: source,
                // target: target,
            };
            languageTranslator.translate(parameters, (error, response) => {
                if (error) reject(error);
                else {
                    const translation = response.translations[0].translation;
                    resolve(translation);
                }
            });
        });
    }

module.exports = {
    translateText,
    detectLanguage,
    listLanguages,
    promiseTranslate
};