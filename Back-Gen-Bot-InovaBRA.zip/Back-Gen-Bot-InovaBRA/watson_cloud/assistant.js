const dotenv = require('dotenv').config({
    path: './.env'
}, {
    encoding: 'utf-8'
});
const watson = require('watson-developer-cloud');
const assistant = new watson.ConversationV1({
    username: process.env.ASSISTANT_USERNAME,
    password: process.env.ASSISTANT_PASSWORD,
    version_date: process.env.ASSISTANT_VERSION_DATE,
    version: process.env.ASSISTANT_VERSION
});

const
    message = (payload, callback) => {
        payload.alternate_intents = false;
        payload.nodes_visited_details = false;
        payload.workspace_id = process.env.ASSISTANT_WORKSPACE;
        assistant.message(payload, (err, res) => {
            if (err) console.log(err);
            else callback(res);
        });
    }

module.exports = {
    message
};