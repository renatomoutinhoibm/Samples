// const dotenv = require('dotenv').config({
//     path: './.env'
// }, {
//     encoding: 'utf-8'
// });
// const Cloudant = require('@cloudant/cloudant');
// const cloudant = Cloudant({
//     account: process.env.CLOUDANT_USERNAME,
//     password: process.env.CLOUDANT_PASSWORD,
//     plugins: 'promises'
// });
// const db = cloudant.db.use(process.env.CLOUDANT_DB);

// module.exports = {

// }