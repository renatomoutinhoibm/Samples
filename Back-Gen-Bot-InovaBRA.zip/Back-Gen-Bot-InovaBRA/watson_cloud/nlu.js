const dotenv = require('dotenv').config({
    path: './.env'
}, {
    encoding: 'utf-8'
});
const NaturalLanguageUnderstandingV1 = require('watson-developer-cloud/natural-language-understanding/v1.js');
const natural_language_undestanding = new NaturalLanguageUnderstandingV1({
    username: process.env.NLU_USERNAME,
    password: process.env.NLU_PASSWORD,
    version_date: process.env.NLU_VERSION_DATE
});
const
    analyze = (input, type, language) => {
        return new Promise((resolve, reject) => {
            const parameters = {
                clean: true,
                language: language,
                features: {
                    sentiment: {}
                }
            };
            if (type == 'text') parameters.text = input;
            else if (type == 'html') {
                parameters.html = input;
                parameters.metadata = {};
            } else if (type == 'url') {
                parameters.url = input;
                parameters.metadata = {}
            };
            natural_language_undestanding.analyze(parameters, (err, response) => {
                if (err) reject(err);
                else resolve(response);
            });
        });
    };

module.exports = {
    analyze
};