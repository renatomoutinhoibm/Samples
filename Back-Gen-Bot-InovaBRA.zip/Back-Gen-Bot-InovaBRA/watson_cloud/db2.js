const dotenv = require('dotenv').config({
    path: './.env'
}, {
    encoding: 'utf-8'
});
const ibmdb = require('ibm_db');
const db2 = {
    db: process.env.DB2_DB,
    hostname: process.env.DB2_HOSTNAME,
    port: process.env.DB2_PORT,
    protocol: process.env.DB2_PROTOCOL,
    username: process.env.DB2_USERNAME,
    password: process.env.DB2_PASSWORD,
    table: process.env.DB2_TABLE
};
const connString =
    `DATABASE=${db2.db};HOSTNAME=${db2.hostname};PORT=${db2.port};PROTOCOL=${db2.protocol};UID=${db2.username};PWD=${db2.password};`;

const
    insert = (workspace_id, conversation_id, assessment, intent, confidence, input, answer, node_0, node_1, node_2) => {
        let queryString = `INSERT INTO ${db2.username}.${db2.table} 
        (WORKSPACE_ID, CONVERSATION_ID, ASSESSMENT, INTENT, CONFIDENCE, 
        INPUT, ANSWER, NODE_0, NODE_1, NODE_2, TIME_) VALUES (
            '${workspace_id}', '${conversation_id}', '${assessment}', 
            '${intent}', ${confidence}, '${input}', '${answer}', 
            '${node_0}', '${node_1}', '${node_2}', (CURRENT_TIMESTAMP - 3 HOURS)
        )`;
        ibmdb.open(connString, (err, conn) => {
            if (err) {
                console.log(err);
                return;
            } else conn.query(queryString, (err1) => {
                if (err1) console.log(err1);
                conn.close((err2) => {
                    if (err2) console.log(err2);
                });
            });
        });
    }

module.exports = {
    insert
};