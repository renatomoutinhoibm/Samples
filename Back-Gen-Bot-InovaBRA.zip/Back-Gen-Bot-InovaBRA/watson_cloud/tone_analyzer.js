const dotenv = require('dotenv').config({
    path: './.env'
}, {
    encoding: 'utf-8'
});
const ToneAnalyzerV3 = require('watson-developer-cloud/tone-analyzer/v3');
const toneAnalyzerV3 = new ToneAnalyzerV3({
    version: process.env.TONE_ANALYZER_VERSION_DATE,
    username: process.env.TONE_ANALYZER_USERNAME,
    password: process.env.TONE_ANALYZER_PASSWORD
});

const
    tone = (text, callback) => {
        const params = {
            tone_input: {
                text: text
            },
            sentences: false,
            content_language: 'en',
            accept_language: 'pt-br',
            content_type: 'application/json',
            tones: []
        };
        toneAnalyzerV3.tone(params, (error, response) => {
            if (error) console.log('error: ', error);
            else callback(response);
        });
    };

const
    toneChat = (utterances, callback) => {
        // Exemplo de utterances
        //
        // utterances = [
        //     {
        //       text: "Hello, I'm having a problem with your product.",
        //       user: "customer"
        //     },
        //     {
        //       text: "OK, let me know what's going on, please.",
        //       user: "agent"
        //     }
        //   ]
        const params = {
            utterances: utterances,
            content_language: 'en',
            accept_language: 'pt-br'
        }
        toneAnalyzerV3.toneChat(params, (error, response) => {
            if (error) console.log('error: ', error);
            else console.log(JSON.stringify(response, null, 2));
        });
    }

module.exports = {
    tone,
    toneChat
};