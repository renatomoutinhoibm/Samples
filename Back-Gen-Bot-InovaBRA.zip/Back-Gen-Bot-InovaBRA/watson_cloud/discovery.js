const dotenv = require('dotenv').config({
    path: './.env'
}, {
    encoding: 'utf-8'
});
const DiscoveryV1 = require('watson-developer-cloud/discovery/v1');
const discovery = new DiscoveryV1({
    username: process.env.DISCOVERY_USERNAME,
    password: process.env.DISCOVERY_PASSWORD,
    version_date: process.env.DISCOVERY_VERSION_DATE
});

/** 
 * @param {String} entity - The Entity to search on documents.
 * @returns {Promise} - The Promise object representing an object of the Discovery response.
 */

const WDSquery = (query, type) => {
    return new Promise((resolve, reject) => {
        const params = {
            url: process.env.DISCOVERY_URL,
            environment_id: process.env.DISCOVERY_ENVIRONMENT,
            collection_id: process.env.DISCOVERY_COLLECTION,
            count: 1,
            return: 'summary'
        };
        if (type === 'query') params.query = `summary:${query}~2`;
        if (type === 'nl-query') params.natural_language_query = query;
        discovery.query(params, (error, data) => {
            if (error) reject(error);
            resolve(data);
        });
    });
}

module.exports = {
    WDSquery
};