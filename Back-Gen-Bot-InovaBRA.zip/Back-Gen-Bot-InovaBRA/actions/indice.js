const
    bacen = require('../services/bacen'),
    title = require('../services/title'),
    discovery = require('../watson_cloud/discovery');

function execute(conv_response) {
    return new Promise((resolve, reject) => {
        // discovery.WDSquery(conv_response.context.indice, 'query').then(documents => {
        //     if (documents.matching_results <= 0) {
        //         conv_response.context.discovery = false;
        //         conv_response.output.text.pop();
        //         if (conv_response.output.alternate) {
        //             conv_response.output.text.push(conv_response.output.alternate);
        //         }
        //     } else {
        //         conv_response.context.discovery = documents.results[0].summary
        //             .replace(/<img[^>]*>/g); // Regex para retirar imagens
        //         if (conv_response.output.alternate && conv_response.output.no_arria) {
        //             conv_response.output.text.push(conv_response.output.alternate);
        //         }
        //     }
        let flagPeriodo = 0;
        feed.getEarliestNews(conv_response.context.indice).then((summary) => {
            console.log("Noticias: " + summary);
            if (summary != null) {
                conv_response.context.discovery = "<p>" + summary.title + "</p><p>" + summary.content + "</p><a href='" + summary.url + "' target='_blank'>Veja aqui a notícia completa</a><p>" + summary.date + "</p>";
                if (conv_response.output.alternate && conv_response.output.no_arria) {
                    conv_response.output.text.push(conv_response.output.alternate);
                }
            } else {
                conv_response.context.discovery = false;
                conv_response.output.text.pop();
                if (conv_response.output.alternate) {
                    conv_response.output.text.push(conv_response.output.alternate);
                }
                console.log("Não achei notícia: " + JSON.stringify(conv_response));
            }
            if (conv_response.context.start_date != null && conv_response.context.end_date != null) {
                // start_month = new Date(conv_response.context.start_date);
                start_month = conv_response.context.start_date;
                end_month = new Date(conv_response.context.end_date)
                end_month = end_month.setMonth(end_month.getMonth() + 1);
                end_month = new Date(end_month);
                end_month = end_month.setDate(end_month.getDate() - 1);
                end_month = formatDate(end_month);
                flagPeriodo = 1;
            }

            // If indice IPCA || IGP, getMonthData from Bacen API, else use getDayData
            if (conv_response.context.indice === 'IPCA' || conv_response.context.indice === 'IGP-M') {
                let start_month;
                let end_month;
                let tempo = 'é';
                let end_month_lastYear = 0;
                let tempo_acumulado = 'dos últimos 12 meses é';

                //If user not type a date set toda`s date
                if (!conv_response.context.start_date) {
                    let initialDate = new Date();
                    start_month = timeSkip(initialDate)[0];
                    end_month = timeSkip(initialDate)[1];
                } else {

                    // If user date > today date
                    if (new Date(conv_response.context.start_date) > Date.now()) {
                        let date = new Date(conv_response.context.start_date);
                        let
                            day = date.getDay() + 2,
                            month = date.getMonth() + 2,
                            year = date.getFullYear();
                        if (month < 10) month = `0${month}`;
                        if (day < 10) day = `0${day}`;
                        conv_response.output.text[0] = `Não sou capaz de prever índices para a data de ${day}/${month}/${year}.`;
                        resolve(conv_response);
                    }
                    else if (new Date(conv_response.context.start_date) < Date.now() && conv_response.context.end_date != (null || undefined)) {
                        let initialDate = new Date(conv_response.context.start_date);
                        start_month = timeSkip(initialDate)[0];
                        end_month = timeSkip(initialDate)[1];
                    }
                    else{
                        let months = ['JAN', 'FEV', 'MAR', 'ABR', 'MAI', 'JUN', 'JUL', 'AGO', 'SET', 'OUT', 'NOV', 'DEZ'];
                        let initialDate = new Date(conv_response.context.start_date);
                        start_month = timeSkip(initialDate)[0];
                        end_month = timeSkip(initialDate)[1];
                        end_month_lastYear = formatDate(new Date(end_month).setFullYear(new Date(end_month).getFullYear()-1))
                        console.log(new Date(end_month).getMonth())
                        tempo = `de ${months[new Date(end_month).getMonth()]} foi`;
                        tempo_acumulado = `entre ${months[new Date(end_month_lastYear).getMonth()]}/${new Date(end_month_lastYear).getFullYear()} a ${months[new Date(end_month).getMonth()]}/${new Date(end_month).getFullYear()} foi`
                    }
                }
                let params = {
                    IPCA: 433,
                    'IGP-M': 189
                    // 'IVG-R': 12466
                };

                // Call Bacen API
                bacen.getBacenMonth(params[conv_response.context.indice], start_month, end_month)
                .then((response) => {
                    // conv_response.output.text[0] = conv_response.output.text[0].replace(conv_response.context.indice, `${conv_response.context.indice} para o mês`)
                    console.log(`data mensal: ${start_month}`)
                    response = JSON.parse(response);
                    console.log(`a resposta ${JSON.stringify(response)}`)
                    if (conv_response.context.emotion.emotion == 'positive') {
                        if (conv_response.context.perfil == 'qualificado') {
                            getAcumulado(params[conv_response.context.indice], end_month, end_month_lastYear||'2017-02-28').then((resp_var) => {
                                getAcumulado(params[conv_response.context.indice], end_month).then((resp_acc) => {
                                    console.log(`resp_acc: ${JSON.stringify(conv_response.output)}`)
                                    // conv_response.output.text[0] = `O ${conv_response.context.indice} acumulado ${tempo_acumulado} XX, no acumulado de 2018 está em YY, no mês ${tempo} ZZ. E representa o maior índice dos últimos 3 meses considerando-se os primeiros 4 dias.`
                                    conv_response.output.text[0] = conv_response.output.text[0].replace('ZZ', response.dataset.data[0][1]).replace('XX', resp_var).replace('YY', resp_acc).replace('PERIODO', tempo_acumulado).replace('foi/e', tempo);
                                    delete conv_response.context.start_date;
                                    resolve(conv_response);
                                    });
                                }).catch((err) => {
                                    console.log(err)
                                });
                            } else {
                                getAcumulado(params[conv_response.context.indice], end_month, end_month_lastYear || '2017-02-28').then((resp_var) => {
                                    // conv_response.output.text[0] = `O ${conv_response.context.indice} acumulado ${tempo_acumulado} XX, no mês ${tempo} ZZ`
                                    console.log(JSON.stringify(conv_response.output.text[0]))
                                    conv_response.output.text[0] = conv_response.output.text[0].replace('ZZ', response.dataset.data[0][1]).replace('XX', resp_var).replace("PERIODO", tempo_acumulado).replace("foi/e", tempo);
                                    delete conv_response.context.start_date;
                                    resolve(conv_response);
                                }).catch((err) => {
                                    console.log(err)
                                });
                            }
                        } else if (flagPeriodo === 1) {
                            calculoPeriodo(params[conv_response.context.indice], response.dataset.data).then((resp) => {
                                conv_response.output.text[0] = conv_response.output.text[0].replace('%%', resp);
                                conv_response.context.start_date = null;
                                delete conv_response.context.end_date;
                                flagPeriodo = 0;
                                delete conv_response.context.start_date;
                                resolve(conv_response);
                            });
                            // let index = calculoPeriodo(433, response.dataset.data);
                            // console.log(`index ${index}`)
                            // resolve(conv_response);
                        } else {
                            // console.log(conv_response);
                            // conv_response.output.text[0] = conv_response.output.text[0].replace('%%', response.dataset.data[0][1]);
                            if (conv_response.context.perfil == 'qualificado') {
                                // conv_response.output.text[0] = `O ${conv_response.context.indice} acumulado ${tempo_acumulado} XX, no mês ${tempo} ZZ`
                                getAcumulado(params[conv_response.context.indice], end_month, end_month_lastYear || '2017-02-28').then((resp_var) => {
                                    conv_response.output.text[0] = conv_response.output.text[0].replace('ZZ', response.dataset.data[0][1]).replace('XX', resp_var).replace('foi/e', tempo).replace('PERIODO', tempo_acumulado);
                                    delete conv_response.context.start_date;
                                    resolve(conv_response);
                                    // getAcumulado(params[conv_response.context.indice], end_month).then((resp_acc) => {
                                    //     conv_response.output.text[0] = conv_response.output.text[0].replace('##', resp_acc);
                                    //     console.log(`resp_acc ${resp_acc}`)
                                    // });
                                });
                            } else {
                                // conv_response.output.text[0] = `O ${conv_response.context.indice} no mês ${tempo} ZZ`
                                conv_response.output.text[0] = conv_response.output.text[0].replace('ZZ', response.dataset.data[0][1]).replace('foi/e', tempo);
                                delete conv_response.context.start_date;
                                resolve(conv_response);
                            }
                        }
                        // console.log(response.dataset);
                    })
                    .catch((errMessage) => {
                        console.log("Error: " + errMessage);
                    })
            } else if (conv_response.context.indice === 'BBDC4' || conv_response.context.indice === 'BBDC3' || conv_response.context.indice === 'BBD'){
                title.getQuotation(conv_response.context.indice).then((resp) => {
                    console.log(resp[0])
                    if (conv_response.context.emotion.emotion == 'positive'){
                        if (conv_response.context.perfil == 'qualificado'){
                            if (conv_response.context.indice === 'BBD') conv_response.output.text[0] = `A ação ${conv_response.context.indice} está avaliada em %%dólares. Tendo variado $$% em relação ao dia anterior, ou ## dólares.`;
                            else conv_response.output.text[0] = `A ação ${conv_response.context.indice} está avaliada em %%reais. Tendo variado $$% em relação ao dia anterior, ou ## reais.`;
                            conv_response.output.text[0] = conv_response.output.text[0].replace('%%', resp[0]).replace('$$', resp[1]).replace('##', resp[2]);
                            resolve(conv_response);
                        } else{
                            if (conv_response.context.indice === 'BBD') conv_response.output.text[0] = `A ação ${conv_response.context.indice} está avaliada em %%dólares. Tendo variado $$% em relação ao dia anterior.`;
                            else conv_response.output.text[0] = `A ação ${conv_response.context.indice} está avaliada em %%reais. Tendo variado $$% em relação ao dia anterior.`;
                            conv_response.output.text[0] = conv_response.output.text[0].replace('%%', resp[0]).replace('$$', resp[1]);
                            resolve(conv_response);
                        }
                    } else{
                        if (conv_response.context.perfil == 'qualificado'){
                            if (conv_response.context.indice === 'BBD') conv_response.output.text[0] = `A ação ${conv_response.context.indice} está avaliada em %%dólares. Tendo variado $$% em relação ao dia anterior.`;
                            else conv_response.output.text[0] = `A ação ${conv_response.context.indice} está avaliada em %%reais. Tendo variado $$% em relação ao dia anterior.`;
                            conv_response.output.text[0] = conv_response.output.text[0].replace('%%', resp[0]).replace('$$', resp[1]);
                            resolve(conv_response);
                        } else{
                            if (conv_response.context.indice === 'BBD') conv_response.output.text[0] = `A ação ${conv_response.context.indice} está avaliada em %%dólares.`;
                            else conv_response.output.text[0] = conv_response.output.text[0].replace('%%', resp[0]);
                            resolve(conv_response);
                        }
                    }
                }).catch((err) => {
                    console.log(err);
                });
            } else if (conv_response.context.indice === 'dólar comercial' || conv_response.context.indice === 'dólar turismo'){
                title.getMoney(conv_response.context.indice).then((resp) => {
                    console.log('DOLAR COMERCIAL')
                    conv_response.output.text[0] = `O ${conv_response.context.indice} está avaliada em ${resp[1]}`;
                    resolve(conv_response);
                    // conv_response.output.text[0] = conv_response.output.text[0].replace('%%', resp);
                }).catch((err) => {
                    console.log(err);
                });
            } else {
                let start_date;
                let params = {
                    Ibovespa: 7,
                    CDI: 12,
                    'dólar': 1,
                    'IVG-R': 12466
                };
                // If user doesn't type a date, set today's date
                if (!conv_response.context.start_date) {
                    start_date = new Date();
                } else {
                    // If user date > today date
                    if (new Date(conv_response.context.start_date) > Date.now()) {
                        let date = new Date(conv_response.context.start_date);
                        let
                            day = date.getDay() + 2,
                            month = date.getMonth() + 2,
                            year = date.getFullYear();
                        if (month < 10) month = `0${month}`;
                        if (day < 10) day = `0${day}`;
                        conv_response.output.text[0] = `Não sou capaz de prever índices para a data de ${day}/${month}/${year}.`;
                        delete conv_response.context.start_date;
                        resolve(conv_response);
                    } else start_date = new Date(conv_response.context.start_date);
                }
                if (conv_response.context.indice === 'IVG-R') {
                    start_date = start_date.setDate(start_date.getDate() - 28);
                } else {
                    if (start_date.getDay() == 0) {
                        start_date = start_date.setDate(start_date.getDate() - 9);
                        console.log(`Domingo`)
                    } else if (start_date.getDay() == 6) {
                        start_date = start_date.setDate(start_date.getDate() - 8);
                        console.log(`Sabado`)
                    } else if (start_date.getDay() == 1) start_date = start_date.setDate(start_date.getDate() - 6);
                    else {
                        start_date = start_date.setDate(start_date.getDate() - 7);
                        console.log(`nomrmal`)
                    }
                }
                start_date = formatDate(start_date);

                // Call Bacen API
                bacen.getBacenDay(params[conv_response.context.indice], start_date, start_date)
                    .then((response) => {
                        response = JSON.parse(response);
                        if (conv_response.context.emotion.emotion == 'positive') {
                            if (conv_response.context.perfil == 'qualificado') {
                                console.log('aqui')
                                getVariacao(params[conv_response.context.indice], start_date).then((resp_var) => {
                                    resp_var = JSON.parse(resp_var);
                                    getAcumulado(params[conv_response.context.indice], start_date).then((resp_acc) => {
                                        if (conv_response.context.indice === 'IVG-R') conv_response.output.text[0] = conv_response.output.text[0].replace('à ontem', 'com o mes passado').replace('dia', 'mes');
                                        conv_response.output.text[0] = conv_response.output.text[0].replace('%%', response.dataset.data[0][1]).replace('$$', resp_var).replace('##', resp_acc);
                                        delete conv_response.context.start_date;
                                        resolve(conv_response);
                                    });
                                    // console.log(`dataset.data ${JSON.stringify(response.dataset.data)}`)
                                }).catch((err) => {
                                    console.log(err)
                                });
                            } else {
                                getVariacao(params[conv_response.context.indice], start_date).then((resp_var) => {
                                    resp_var = JSON.parse(resp_var);
                                    // console.log(`dataset.data ${JSON.stringify(response.dataset.data)}`)
                                    if (conv_response.context.indice === 'IVG-R') conv_response.output.text[0] = conv_response.output.text[0].replace('à ontem', 'com o mes passado').replace('dia', 'mes');
                                    conv_response.output.text[0] = conv_response.output.text[0].replace('%%', response.dataset.data[0][1]).replace('$$', resp_var);
                                    delete conv_response.context.start_date;
                                    resolve(conv_response);
                                }).catch((err) => {
                                    console.log(err)
                                });
                            }
                        } else {
                            conv_response.output.text[0] = conv_response.output.text[0].replace('%%', response.dataset.data[0][1]);
                            if (conv_response.context.perfil == 'qualificado') {
                                getVariacao(params[conv_response.context.indice], start_date).then((resp_var) => {
                                    conv_response.output.text[0] = conv_response.output.text[0].replace('$$', resp_var);
                                    getAcumulado(params[conv_response.context.indice], start_date).then((resp_acc) => {
                                        if (conv_response.context.indice === 'IVG-R') conv_response.output.text[0] = conv_response.output.text[0].replace('dia', 'mês').replace('periodo', 'ano');
                                        conv_response.output.text[0] = conv_response.output.text[0].replace('##', resp_acc);
                                        // console.log(`resp_acc ${resp_acc}`)
                                        delete conv_response.context.start_date;
                                        resolve(conv_response);
                                    });
                                });
                            } else {
                                delete conv_response.context.start_date;
                                resolve(conv_response);
                            }
                            console.log(response.dataset);
                        }
                    })
                    .catch((errMessage) => {
                        console.log("Error: " + errMessage);
                    });
            }
            // If bot needs to call Arria API
        }).catch(e => console.log(e));
    })
}

function timeSkip(date) {
    let
        data = new Date(date),
        data_2 = new Date(date);

    data = data.setDate(1);
    data = new Date(data);
    data = data.setMonth(data.getMonth() - 2);
    data = formatDate(data);
    data_2 = data_2.setDate(1);
    data_2 = new Date(data_2);
    data_2 = data_2.setDate(data_2.getDate() - 1);
    data_2 = formatDate(data_2);
    return [data, data_2];
}

function formatDate(date) {
    let
        d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
    return [year, month, day].join('-');
}

function calculoPeriodo(indice, data) {
    switch (indice) {
        case 189:
        case 433:
            // console.log(data.map((obj, i)=>{
            //     return obj[1]
            // }).reduce((acc, elem)=>{
            //     return acc+elem;
            // }));
            return new Promise((resolve, reject) => {
                resolve(data.map((obj, i) => {
                    return obj[1]
                }).reduce((acc, elem) => {
                    return acc + elem;
                }));
            });
            break;
    }
}

function getVariacao(indice, lastDate) {
    return new Promise((resolve, reject) => {
        let variation;
        switch (indice) {
            case 433:
            case 189:
                bacen.getBacenMonth(indice, timeSkip(lastDate)[0], timeSkip(lastDate)[1]).then((resp_getVariacao) => {
                    resp_getVariacao = JSON.parse(resp_getVariacao);
                    let base = resp_getVariacao.dataset.data[1][1];
                    let current = resp_getVariacao.dataset.data[0][1];
                    variation = current / base;
                    if (variation > 1) {
                        variation = variation - 1;
                        variation = parseFloat(variation.toFixed(2)) * 10;
                        console.log(resp_getVariacao.dataset.data);
                        resolve(variation.toFixed(2));
                    } else if (variation < 1) {
                        variation = 1 - variation;
                        variation = parseFloat(variation.toFixed(2)) * -10;
                        resolve(variation.toFixed(2));
                    } else {
                        variation = 0
                        resolve(variation);
                    }
                });
                break;

            case 1:
            case 7:
            case 12:
            case 12466:
                let date = new Date(lastDate);
                date = date.setDate(date.getDate() - 1);
                date = formatDate(date)
                console.log(`a data e ${date}`)
                bacen.getBacenDay(indice, date, lastDate).then((resp_getVariacao) => {
                    console.log(date)
                    let base;
                    let current;
                    resp_getVariacao = JSON.parse(resp_getVariacao);
                    if (resp_getVariacao.dataset.data[0]) {
                        current = resp_getVariacao.dataset.data[0][1];
                        if (resp_getVariacao.dataset.data[1]) {
                            base = resp_getVariacao.dataset.data[1][1];
                        } else base = current;
                    } else reject(resp_getVariacao);
                    variation = current / base;
                    if (variation > 1) {
                        variation = variation - 1;
                        variation = parseFloat(variation.toFixed(3)) * 10;
                        console.log(resp_getVariacao.dataset.data);
                        resolve(variation);
                    } else if (variation < 1) {
                        variation = 1 - variation;
                        variation = parseFloat(variation.toFixed(3)) * -10;
                        resolve(variation);
                    } else {
                        variation = 0
                        resolve(variation);
                    }
                }).catch((err) => {
                    console.log(err)
                });
                // console.log(timeSkip(lastDate))
                break;
        }
    });
}

function getAcumulado(indice, lastDate, yearDate) {
    return new Promise((resolve, reject) => {
        switch (indice) {
            case 433:
            case 189:
                bacen.getBacenMonth(indice, yearDate||'2018-01-31', lastDate).then((resp_getAcumulado) => {
                    let result = JSON.parse(resp_getAcumulado);
                    result = result.dataset.data
                    // console.log(result);
                    let x = 0;
                    result.map((obj, i) => {
                        console.log(`obj ${obj[1]}`)
                        if (i == result.length-1) resolve((x+obj[1]).toFixed(2));
                        else if(i == 0) return x += 0;
                        else return x += obj[1];
                    });
                }).catch((err) => {
                    console.log(err)
                });
                break;

            case 12:
                bacen.getBacenMonth(indice, '2018-01-01', lastDate).then((resp_getAcumulado) => {
                    let result = JSON.parse(resp_getAcumulado);
                    result = result.dataset.data
                    let x = 0;
                    result.map((obj, i) => {
                        // console.log(`obj ${obj[1]}`)
                        if (i == result.length - 1) resolve((x + obj[1]).toFixed(2));
                        return x += obj[1];
                    });
                });
                break;
            case 12466:
            case 1:
            case 7:
                let variation = 0;
                bacen.getBacenMonth(indice, '2018-01-01', lastDate).then((resp_getAcumulado) => {
                    let result = JSON.parse(resp_getAcumulado);
                    result = result.dataset.data
                    // console.log(result);
                    let base = result[result.length - 1][1];
                    let current = result[0][1];
                    variation = current / base;
                    if (variation > 1) {
                        variation = variation - 1;
                        variation = parseFloat(variation) * 10;
                        // console.log(resp_getVariacao.dataset.data);
                        resolve(variation.toFixed(3));
                    } else if (variation < 1) {
                        variation = 1 - variation;
                        variation = parseFloat(variation) * -10;
                        resolve(variation.toFixed(3));
                    } else {
                        variation = 0
                        resolve(variation);
                    }
                }).catch((err) => {
                    console.log(err)
                });
                break;
        }
    });
}

module.exports = {
    execute
}