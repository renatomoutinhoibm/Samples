arria = require('../services/arria');
translator2 = require('../google/translator');

function execute(conv_response) {

    return new Promise((resolve, reject) => {
        console.log("demo ativada");
        //console.log(conv_response);
        let shock;
        let indiceDemo;

        if (conv_response.context.direction === "crescimento") {
            shock = 1 + (parseInt(conv_response.context.shock) / 100);
        } else if (conv_response.context.direction === "decrescimento") {
            shock = 1 - (parseInt(conv_response.context.shock) / 100);
        }

        switch (conv_response.context.indice) {
            case "Ibovespa":
                indiceDemo = "S&P 500 Index"
                break;
            case "CDI":
                indiceDemo = "NYSE MKT Composite Index"
                break;
            case "IGP-M":
                indiceDemo = "CAC 40 Index"
                break;
            case "IPCA":
                indiceDemo = "Nikkei 225 Index"
                break;
            case "IVG-R":
                indiceDemo = "NASDAQ Composite Index"
                break;
            default:
                indiceDemo = "S&P 500 Index"
        }
        console.log("Indice: " + indiceDemo + " Shock: " + shock);
        arria.naturalLanguageGeneration(indiceDemo, shock).then((arria_response) => {
            //console.log(arria_response);
            let regex = new RegExp(indiceDemo, "gi");
            let alltext = JSON.stringify(arria_response).replace(regex, conv_response.context.indice);
            arria_response = JSON.parse(alltext);
            // Tradutor
            let promises = [];
            if (arria_response.overview != undefined) promises.push(translator2.promiseTranslate(arria_response.overview, "en", "pt"))
            if (arria_response.detailedAnalysis != undefined) promises.push(translator2.promiseTranslate(arria_response.detailedAnalysis, "en", "pt"))
            if (arria_response.marketChanges != undefined) promises.push(translator2.promiseTranslate(arria_response.marketChanges, "en", "pt"))
            if (arria_response.modelDetails != undefined) promises.push(translator2.promiseTranslate(arria_response.modelDetails, "en", "pt"))
            if (promises.length > 0) Promise.all(promises).then((responses) => {
                //console.log(JSON.stringify(responses));
                responses.forEach((value, index) => {
                    responses[index] = responses[index][0];
                })
                //console.log(JSON.stringify(responses));
                conv_response.output.modal = responses.join("");

                // send different response if emotion is positive or negative
                if (conv_response.context.emotion && conv_response.context.perfil) {
                    if (conv_response.context.perfil === 'iniciante') {
                        if (conv_response.context.emotion.emotion === 'positive') {
                            let newArray = responses.slice(0, 2);
                            conv_response.output.text.push(newArray.join(""));
                            delete conv_response.context.direction;
                            delete conv_response.context.shock;
                        } else {
                            let newArray = responses.slice(0, 1);
                            conv_response.output.text.push(newArray.join(""));
                            delete conv_response.context.direction;
                            delete conv_response.context.shock;
                        }
                    }
                    if (conv_response.context.perfil === 'qualificado') {
                        if (conv_response.context.emotion.emotion === 'positive') {
                            let newArray = responses.slice(0, 2);
                            newArray.push(responses[3]);
                            conv_response.output.text.push(newArray.join(""));
                            delete conv_response.context.direction;
                            delete conv_response.context.shock;
                        } else {
                            let newArray = responses.slice(0, 2);
                            conv_response.output.text.push(newArray.join(""));
                            delete conv_response.context.direction;
                            delete conv_response.context.shock;
                        }
                    }
                } else {
                    let newArray = responses.slice(0, 2);
                    conv_response.output.text.push(newArray.join(""));
                    delete conv_response.context.direction;
                    delete conv_response.context.shock;
                }

                resolve(conv_response);
            })
        }).catch((err) => {
            reject(err);
        })
    })

}

module.exports = {
    execute
}