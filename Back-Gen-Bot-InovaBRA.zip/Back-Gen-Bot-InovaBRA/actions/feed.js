var feed = require("feed-read-parser");
var http = require("request-promise-native");

let rssFeed = ["http://www.infomoney.com.br/mercados/acoes-e-indices/rss",
    "http://www.infomoney.com.br/mercados/renda-fixa/rss",
    "http://www.infomoney.com.br/onde-investir/rss",
    "http://www.infomoney.com.br/mercados/rss",
    "http://www.infomoney.com.br/bloomberg/mercados/rss",
    "http://www.infomoney.com.br/imoveis/rss"
];

var getEarliestNews = (query) => {
    return new Promise((resolve, reject) => {
        feed(rssFeed, function (err, articles) {
            if (err) {
                reject(err);
            } else {
                let urls = [];
                for (article of articles) {
                    if (article.title.includes(query)) {
                        urls.push({
                            url: article.link,
                            date: article.published
                        });
                    }
                }
                //console.log("URLs Found: "+urls)
                if (urls.length > 0) {
                    let earliest_url = getEarliestDate(urls);
                    summarize(earliest_url).then(function (repos) {
                        //console.log(repos);
                        resolve({
                            title: repos.sm_api_title,
                            content: repos.sm_api_content,
                            url: earliest_url.url,
                            date: formatDate(earliest_url.date)
                        })
                    }).catch(function (err) {
                        resolve(null);
                    });
                } else {
                    resolve(null);
                }
            }
        });
    })
}

var getFeed = (query) => {
    return new Promise((resolve, reject) => {
        feed(rssFeed, function (err, articles) {
            if (err) {
                reject(err);
            } else {
                let urls = [];
                for (article of articles) {
                    if (article.title.includes(query)) {
                        urls.push({
                            url: article.link,
                            date: article.published
                        });
                    }
                }
                resolve(urls);
            }
        });
    })
}

summarize = (url) => {
    var options = {
        uri: 'https://api.smmry.com',
        qs: {
            SM_API_KEY: "FFC155DABB",
            SM_LENGTH: '1',
            SM_URL: url.url
        },
        headers: {
            'User-Agent': 'Request-Promise'
        },
        json: true // Automatically parses the JSON string in the response
    };

    return http(options)
}

function getEarliestDate(urls) {
    var max_dt_url = urls[0],
        max_dtObj = new Date(urls[0].date);
    urls.forEach(function (dt, index) {
        if (new Date(dt.date) > max_dtObj) {
            max_dt_url = dt;
            max_dtObj = new Date(dt.date);
        }
    });
    return max_dt_url;
}

function formatDate(date) {
    let
        d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();
    hour = d.getHours();
    minutes = d.getMinutes();
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
    return [year, month, day].join('-') + " " + [hour, minutes].join(':');
}

module.exports = {
    getEarliestNews,
    getFeed
}