import { ChatBubble } from './components/chatbubble/chatbubble.model'
import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()

export class ChatService {

    public messages: Array<ChatBubble> = [];
    private watsonObject: any;
    private url: string = 'https://inovabra-backend.mybluemix.net';
    constructor(private http: Http) {
        this.watsonObject = {
            context: {
                conversation_id: null,
                perfil: null
            }
        };
    }

    submitMessage(text: string, user: string, modal: boolean, modalText: string, type: string) {
        if (text != "" && text != " ") {
            this.messages.push(new ChatBubble(text, user, modal, modalText, type));
            return this.messages[this.messages.length-1]
        }
    }

    deleteMessage(bubble:ChatBubble){
        let index = this.messages.findIndex(serv => serv === bubble);
        this.messages.splice(index,1);
    }

    submitFeedback(id: ChatBubble, feedback: string) {
        let index = this.messages.findIndex(serv => serv === id);
        this.messages[index].submitFeedback(feedback);

        let body = this.watsonObject;
        body.assessment = feedback;

        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        this.http.post(this.url + '/api/feedback', body, { headers: headers }).map(res => res.json())
            .subscribe(response => {
                console.log(response);
            }, error => {
                //this.submitMessage("Desculpe, estou sem acesso ao serviço de feedback.", "watson", false, null);
                console.log(error);
            });
    }

    sendToWatson(text: string) {
        this.submitMessage(text, "user", false, null, null);

        // retrieving user profile
        var element = <HTMLInputElement> document.getElementById('switch');
        var isBeginner = element.checked;
        if (isBeginner == true) this.watsonObject.context.perfil = 'iniciante';
        else this.watsonObject.context.perfil = 'qualificado';

        let watsonObject = this.watsonObject;
        let headers = new Headers();
        let body = {
            "input": {
                "text": text
            },
            "context": watsonObject.context
        }
        headers.append('Content-Type', 'application/json');
        let gif;
        this.http.post(this.url + '/api/conversation', body, { headers: headers }).map(res => res.json())
            .subscribe(watsonObject => {
                // console.log('watsonObject: ' + JSON.stringify(watsonObject.context,null,2));

                if (watsonObject.context && watsonObject.context.emotion) {
                    // updating user stress level bar
                    var element = <HTMLInputElement> document.getElementById('stress-bar');
                    var emotionScore = watsonObject.context.emotion.score;
                    var stress = 0;
                    if (emotionScore < 0) {
                        // if user is angry
                        emotionScore = Math.abs(emotionScore);
                        stress = (emotionScore+1)*50;
                        element.setAttribute('class','determinate red-theme');
                    } else {
                        stress = 50*(1-emotionScore);
                        if (emotionScore == 0) element.setAttribute('class','determinate yellow');
                        else element.setAttribute('class','determinate green darken-2');
                    }
                    element.setAttribute('style','width:' + stress + '%');
                }

                clearTimeout(timer);
                if(gif != null){
                    this.deleteMessage(gif);
                    gif = null;
                }
                this.iteractionOutputTextArray(watsonObject);
            }, error => {
                this.submitMessage("Desculpe, estou sem acesso ao servidor de back-end.", "watson", false, null, "system");
                console.log(error);
            });

        if (!text.includes('ibovespa') || !text.includes('Ibovespa') || !text.includes('cdi') || !text.includes('CDI') || !text.includes('dolar') || !text.includes('dólar') || !text.includes('Dólar') || !text.includes('Dolar') || !text.includes('ipca') || !text.includes('IPCA') || !text.includes('igpm') || !text.includes('igp-m') || !text.includes('IGPM') || !text.includes('IGP-M') || !text.includes('ivgr') || !text.includes('ivg-r') || !text.includes('IVGR') || !text.includes('IVG-R') || !text.includes('ivg') || !text.includes('IVG')){
                var timer = setTimeout(()=>{
                    gif = this.submitMessage("../assets/loading4.gif", "watson", false, null, 'image');
                }, 3000);
            }
    }

    private iteractionOutputTextArray(watsonObject) {
        this.watsonObject = watsonObject;
        let type = null;
        if (watsonObject.output.system) type = "system";

        if (watsonObject.output.modal) {
            if (watsonObject.output.text.length > 1) {
                for (let i = 0; i < watsonObject.output.text.length; i++) {
                    type = "system";
                    let modal = false
                    if (watsonObject.output.text.length - 1 == i && watsonObject.output.system == undefined) {
                        type = null;
                        modal = true;
                    }
                    this.submitMessage(watsonObject.output.text[i], "watson", modal, watsonObject.output.modal, type);
                }
            }
            else if (watsonObject.output.text.length == 1) {
                this.submitMessage(watsonObject.output.text[0], "watson", true, watsonObject.output.modal, type);
            }
        } else {
            if (watsonObject.output.text.length > 1) {
                for (let i = 0; i < watsonObject.output.text.length; i++) {
                    type = "system";
                    if (watsonObject.output.text.length - 1 == i && watsonObject.output.system == undefined) type = null;
                    this.submitMessage(watsonObject.output.text[i], "watson", false, null, type);
                }
            } else if (watsonObject.output.text.length == 1) {
                this.submitMessage(watsonObject.output.text[0], "watson", false, null, type);
            }
        }
    }
}
