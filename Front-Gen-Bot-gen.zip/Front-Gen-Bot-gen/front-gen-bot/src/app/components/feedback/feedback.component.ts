import { Component, OnInit, Input } from '@angular/core';

import { ChatService } from '../../chat.service';
import { ChatBubble } from '../chatbubble/chatbubble.model';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

  @Input() public motherBubble: ChatBubble;

  public chatArray: number;

  constructor(private chatService: ChatService) {
    this.chatArray = this.chatService.messages.length;
  }

  ngOnInit() { }

  positive() {
    this.chatService.submitFeedback(this.motherBubble, "correct");
    // this.serv.list().subscribe(res => { this.resp = res; this.resp.assesment = "true"; }, err => { console.log(err) }, () => { this.serv.send(this.resp).subscribe()});
  }

  negative() {
    this.chatService.submitFeedback(this.motherBubble, "wrong");
    // this.serv.list().subscribe(res => { this.resp = res; this.resp.assesment = "false"; }, err => { console.log(err) }, () => { this.serv.send(this.resp).subscribe() });
  }



}
