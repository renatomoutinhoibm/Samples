import { Component, OnInit, EventEmitter } from '@angular/core';
import { MaterializeAction } from 'angular2-materialize';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.css'],
  
})
export class ModalComponent implements OnInit {

  actions = new EventEmitter<string | MaterializeAction>();
  modalText: string

  constructor() { }

  ngOnInit() { }

  DialogOpen(modalText: string) {
    this.modalText = modalText;
    this.actions.emit({ action: 'modal', params: ['open'] });
  }

  DialogClose() {
    this.actions.emit({ action: 'modal', params: ['close'] });
  }

}
