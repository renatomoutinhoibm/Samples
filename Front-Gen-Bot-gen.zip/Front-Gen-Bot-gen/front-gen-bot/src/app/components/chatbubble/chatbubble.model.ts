export class ChatBubble {

    public text: string;
    public user: string;
    public feedback: string;
    public modal: boolean;
    public modalText: string;
    public type: string;

    constructor(text: string, user: string, modal: boolean, modalText: string, type: string) {
        this.text = text;
        this.user = user;
        this.feedback = "none";
        this.modal = modal;
        this.modalText = modalText;
        this.type = type;
    }

    submitFeedback(feedback: string) {
        this.feedback = feedback;
    }

}