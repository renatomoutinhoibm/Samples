import { Component, OnInit, Input, ViewChild } from '@angular/core';

import { ChatBubble } from './chatbubble.model';
import { ModalComponent } from '../modal/modal.component';
import { ChatService } from '../../chat.service';

@Component({
  selector: 'app-chatbubble',
  templateUrl: './chatbubble.component.html',
  styleUrls: ['./chatbubble.component.css'],
  providers: [ModalComponent]
})
export class ChatBubbleComponent implements OnInit {

  @Input() public chatInfo: ChatBubble;

  public chatArray: number;

  constructor(private chatService: ChatService) {
    this.chatArray = this.chatService.messages.length;
  }

  ngOnInit() { }

  @ViewChild(ModalComponent)
  private modal: ModalComponent;

  DialogOpen() {
    this.modal.DialogOpen(this.chatInfo.modalText);
  }

}
