import { Component, OnInit, EventEmitter, AfterViewChecked, ElementRef, ViewChild } from '@angular/core';
import { ChatBubble } from '../chatbubble/chatbubble.model';
import { ChatService } from '../../chat.service';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css']
})

export class ChatComponent implements OnInit {

  @ViewChild('scrollMe') private myScrollElement: ElementRef;
  userTexts: Array<ChatBubble>;
  inputText: string;
  private user:string;

  constructor(private chatService: ChatService) {
    this.userTexts = chatService.messages;
    this.user = "user";
  }

  ngOnInit() {
    this.chatService.sendToWatson("");
    var element = <HTMLInputElement> document.getElementById('user-input');
    element.focus();
  }

  ngAfterViewChecked() {
    this.scrollToBottom();
  }

  scrollToBottom(): void {
    try {
      this.myScrollElement.nativeElement.scrollTop = this.myScrollElement.nativeElement.scrollHeight;
    } catch (err) { }
  }

  onSubmit(e) {
    e.preventDefault();
    if(this.inputText != ""){
      if(this.userTexts.length > 0 && this.userTexts[this.userTexts.length-1].feedback == "none" && this.userTexts[this.userTexts.length-1].user == "watson"){
        this.chatService.submitFeedback(this.userTexts[this.userTexts.length-1], "skipped");
      }
      //this.userTexts.push(new ChatBubble(this.inputText, "user"));
      this.chatService.sendToWatson(this.inputText);
      this.inputText = '';
    }
    
  }


}
