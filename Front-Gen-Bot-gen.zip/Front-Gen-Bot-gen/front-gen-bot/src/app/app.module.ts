import { BrowserModule } from '@angular/platform-browser';
import { MaterializeModule } from 'angular2-materialize';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { Http, Headers } from '@angular/http';

import { AppComponent } from './app.component';
import { ChatComponent } from './components/chat/chat.component';

import { FeedbackComponent } from './components/feedback/feedback.component';
import { ModalComponent } from './components/modal/modal.component';
import { ChatService } from './chat.service'
import { ChatBubbleComponent } from './components/chatbubble/chatbubble.component';

const appRoutes: Routes = [
  {path: '', component: AppComponent},
  {path: '**', redirectTo: ''}
]


@NgModule({
  declarations: [
    AppComponent,
    ChatComponent,
    FeedbackComponent,
    ModalComponent,
    ChatBubbleComponent,
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    RouterModule.forRoot(appRoutes),
    MaterializeModule
  ],
  providers: [ChatService],
  bootstrap: [AppComponent]
})
export class AppModule { }
